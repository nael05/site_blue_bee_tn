<?php
date_default_timezone_set('Europe/Paris');

// Configuration Stripe
define('STRIPE_SECRET_KEY', 'sk_test_51SveS3GVUrvXkdUM6OuXmd4c3awJRxlyoRoQzxVX0StcOQGwlOFRqqvKM2aNzHyCwF4aWAbNXatETc3ILc4yLzPD00a3LzuJNg');
define('STRIPE_PUBLIC_KEY', 'pk_test_51SveS3GVUrvXkdUMxud5AUuybCoXrJsw01w6fcQGVjrf4lvjOzo4QqnMaxuWZDt7iy3sA74Kqht5f9yvpvtUuGJs00Hzf6mVeK');

// Configuration Base de donnees (InfinityFree)
define('DB_HOST', 'sql303.infinityfree.com');
define('DB_NAME', 'if0_41864032_resto');
define('DB_USER', 'if0_41864032');
define('DB_PASS', '__A_REMPLIR_AVANT_UPLOAD__');

// Configuration Brevo (envoi d'emails transactionnels)
// IMPORTANT : l'adresse BREVO_SENDER_EMAIL doit etre verifiee dans
// l'interface Brevo (Senders, Domains & Dedicated IPs > Senders).
define('BREVO_API_KEY',      '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');
define('BREVO_SENDER_EMAIL', 'nanaililnail99@gmail.com');
define('BREVO_SENDER_NAME',  'BlueBeeTN');

// Token secret pour declencher le cron quotidien via HTTP (au cas ou
// l'hebergeur ne propose pas de cron classique). Mettre une valeur
// aleatoire et la garder secrete.
define('CRON_DAILY_TOKEN', '22603044c60369fffe43ad4671e9f435d2c94a1f75f395fe');

// CA bundle pour les appels cURL HTTPS (Stripe, Brevo). Si le chemin
// n'existe pas (en prod), la verification SSL utilisera le bundle systeme.
define('CACERT_PATH', '');
